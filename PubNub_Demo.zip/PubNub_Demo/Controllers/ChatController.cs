﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using PubNub_Demo.Models;
using PubNub_Demo.Service;

namespace PubNub_Demo.Controllers;

public class ChatController : Controller
{
    private readonly DataService _dataService;
    private readonly PubNubService _pubnubService;

    public ChatController(DataService dataService, PubNubService pubnubService, ITempDataDictionaryFactory tempDataDictionaryFactory)
    {
        _dataService = dataService;
        _pubnubService = pubnubService;
    }

    public string StartListening(Guid id)
    {
        if (id != Guid.Empty)
        {
            var sender = GetSender();
            if (sender == null) return string.Empty;

            var channel = _dataService.GetChannel(id, sender.Value);
            var result = _pubnubService.StartSubscription(channel.ChannelName);
            if (result == null || (result != null && result.Sender == sender))
                return string.Empty;
            var receivedFrom = _dataService.GetUser(result.Sender);
            _pubnubService.MarkMessageAsReceived();
            return receivedFrom?.Name ?? string.Empty;
        }
        return string.Empty;
    }

    public async Task<IActionResult> Index()
    {
        if (!IsUserSessionActive())
        {
            return RedirectToAction("Index", "Login");
        }

        var sender = GetSender();

        var users = await _dataService.GetUsersAndSubscribe(HttpContext.Session.GetString("user")!.ToLower(), sender.Value);
        return View(users);
    }

    [HttpPost]
    public async Task<IActionResult> GetMessages(Guid id)
    {
        var sender = GetSender();
        if (sender == null) return Unauthorized();

        var channel = _dataService.GetChannel(sender.Value, id);
        var messages = _dataService.GetMessages(sender.Value, id);
        var user = _dataService.GetUser(id);

        var messageModel = new ChatMessagesViewModel
        {
            ContactId = id,
            ContactName = user != null ? user.Name! : string.Empty,
            Messages = messages?.Select(x => new ChatMessage
            {
                Receiver = x.Receiver,
                DateTime = x.DateTime,
                Message = x.Message,
                MessageId = x.MessageId,
                Sender = x.Sender,
            }).ToList() ?? new List<ChatMessage>()
        };

        return PartialView("~/Views/Chat/_ChatMessage.cshtml", messageModel);
    }

    [HttpPost]
    public async Task<IActionResult> SendMessage(string message, Guid id)
    {
        var sender = GetSender();
        if (sender == null) return Unauthorized();

        var chatMessage = new ChatMessage
        {
            MessageId = Guid.NewGuid(),
            DateTime = DateTime.Now,
            Message = message,
            Receiver = id,
            Sender = sender.Value
        };

        return Ok(await _dataService.SendMessage(chatMessage));
    }

    private Guid? GetSender()
    {
        if (!IsUserSessionActive())
            return null;

        return Guid.Parse(HttpContext.Session.GetString("userid")!);
    }

    private bool IsUserSessionActive()
    {
        if (string.IsNullOrWhiteSpace(HttpContext.Session.GetString("userid")))
            return false;

        return true;
    }
}
