﻿using Microsoft.AspNetCore.Mvc;
using PubNub_Demo.Service;

namespace PubNub_Demo.Controllers;
public class LoginController : Controller
{
    private readonly DataService _dataService;
    public LoginController(DataService dataService)
    {
        _dataService = dataService;
    }

    public IActionResult Index()
    {
        if (!string.IsNullOrWhiteSpace(HttpContext.Session.GetString("user")))
        {
            return RedirectToAction("Index", "Chat");
        }
        return View();
    }

    [HttpPost]
    public IActionResult Index(string username, string password)
    {
        var result = _dataService.CheckLogin(username, password);

        if (result != null)
        {
            HttpContext.Session.SetString("user", username);
            HttpContext.Session.SetString("userid", result.UserId.ToString());
            return RedirectToAction("Index", "Chat");
        }

        return View();
    }

    public IActionResult Register()
    {
        if (!string.IsNullOrWhiteSpace(HttpContext.Session.GetString("user")))
        {
            return RedirectToAction("Index", "Chat");
        }
        return View();
    }


    [HttpPost]
    public IActionResult Register(string username, string password, string name)
    {
        var result = _dataService.AddUser(username, password, name);

        if (result)
            return RedirectToAction("Index", "Login");
        return View();
    }

    public IActionResult Logout()
    {
        HttpContext.Session.Clear();
        return RedirectToAction("Index");
    }
}
