﻿namespace PubNub_Demo.Models;

public class ChatMessagesViewModel
{
    public Guid ContactId { get; set; }
    public string ContactName { get; set; } = string.Empty;
    public List<ChatMessage> Messages { get; set; } = new();
}
