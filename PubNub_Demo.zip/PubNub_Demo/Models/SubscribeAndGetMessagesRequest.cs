﻿namespace PubNub_Demo.Models;

public class SubscribeAndGetMessagesRequest
{
    public Guid Sender { get; set; }
    public Guid Receiver { get; set; }
}
