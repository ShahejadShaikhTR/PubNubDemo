﻿namespace PubNub_Demo.Models;

public class MessageReceivedEventArgs : EventArgs
{
    public string Channel { get; set; }
    public object Payload { get; set; }
}
