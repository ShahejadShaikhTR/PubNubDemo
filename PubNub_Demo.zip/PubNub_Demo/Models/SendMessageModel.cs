﻿namespace PubNub_Demo.Models;

public class SendMessageModel
{
    public Guid Sender { get; set; }
    public Guid Receiver { get; set; }
    public Guid ChannelId { get; set; }
    public string? Message { get; set; }
}
