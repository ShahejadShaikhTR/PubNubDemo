﻿namespace PubNub_Demo.Models;

public class ChatMessage
{
    public Guid MessageId { get; set; }
    public string? Message { get; set; }
    public Guid Sender { get; set; }
    public Guid Receiver { get; set; }
    public DateTime DateTime { get; set; }
}
