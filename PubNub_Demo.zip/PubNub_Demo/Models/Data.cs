﻿namespace PubNub_Demo.Models;

public class Data
{
    public List<PrivateChannel> PrivateChannels { get; set; } = new();
    public List<User> Users { get; set; } = new();
    public List<ChatMessage> ChatMessages { get; set; } = new();
}
