﻿namespace PubNub_Demo.Models;
public class PrivateChannel
{
    public Guid ChannelId { get; set; }
    public string? ChannelName { get; set; }
    public Guid Initiator { get; set; }
    public Guid Spectator { get; set; }
}
