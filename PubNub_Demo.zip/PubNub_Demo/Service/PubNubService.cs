﻿using Newtonsoft.Json;
using PubNub_Demo.Models;
using PubnubApi;

namespace PubNub_Demo.Service;

public class PubNubService
{
    private readonly IConfiguration _configuration;
    private readonly Pubnub _pubnub;
    public event EventHandler<MessageReceivedEventArgs> MessageReceived;
    public ChatMessage _message;

    public PubNubService(IConfiguration configuration)
    {
        _configuration = configuration;

        PNConfiguration pnConfiguration = new PNConfiguration(new UserId(Guid.NewGuid().ToString()));
        pnConfiguration.SubscribeKey = _configuration["PubNub:SubscribeKey"];
        pnConfiguration.PublishKey = _configuration["PubNub:PublishKey"];
        pnConfiguration.SecretKey = _configuration["PubNub:SecretKey"];

        _pubnub = new Pubnub(pnConfiguration);
    }

    public async Task<List<string>> GetSubscribedChannels(string token)
    {
        _pubnub.SetAuthToken(token);
        List<string> subscribedChannels = _pubnub.GetSubscribedChannels();
        return subscribedChannels != null ? subscribedChannels : new List<string>();
    }

    public async Task<bool> IsChannelSubscribedAsync(string channel)
    {
         var result = await _pubnub.HereNow()
            .Channels(new[] { channel })
            .IncludeUUIDs(true)
            .IncludeState(false)
            .ExecuteAsync();

        if (result.Status.Error)
        {
            return false;
        }

        return result.Result.Channels.ContainsKey(channel);
    }

    public async Task<bool> SubscribeChannels(List<string> channelNames, string token)
    {
        if (channelNames?.Any() != true)
            return false;

        _pubnub.SetAuthToken(token);
        _pubnub.Subscribe<string>()
                 .Channels(channelNames.ToArray())
                 .Execute();
        return true;
    }

    public async Task<string> GrantToken(Guid userId, List<PrivateChannel> channels)
    {
        var tokenChannels = new Dictionary<string, PNTokenAuthValues>();
        foreach (var channel in channels)
        {
            tokenChannels.Add(channel.ChannelName, new PNTokenAuthValues() { Read = true, Write = true });
        }

        PNResult<PNAccessManagerTokenResult> grantTokenResponse = await _pubnub.GrantToken().TTL(300)
            .AuthorizedUserId(new UserId(userId.ToString()))
            .Resources(new PNTokenResources()
            {
                Channels = tokenChannels
            }).ExecuteAsync();

        if (grantTokenResponse.Status.Error && grantTokenResponse.Status.ErrorData != null)
        {
            Console.WriteLine($"Error: {grantTokenResponse.Status.ErrorData.Information}");
            return string.Empty;
        }

        return grantTokenResponse.Result.Token;
    }

    public async Task PublishMessage(string message, string channel, Guid sender)
    {
        PNResult<PNPublishResult> publishResult = await _pubnub.Publish()
        .Channel(channel)
        .Message(new ChatMessage { Message = message, Sender = sender })
        .ExecuteAsync();
    }

    public void MarkMessageAsReceived()
    {
        _message = null;
    }

    public ChatMessage StartSubscription(string channel)
    {
        _pubnub.AddListener(new SubscribeCallbackExt(
            (pubnubObj, message) =>
            {
                if (message.Channel == channel)
                {
                    _message = JsonConvert.DeserializeObject<ChatMessage>(message.Message.ToString());
                }
            },
            (pubnubObj, presence) =>
            {
                // Handle presence events (optional)
                Console.WriteLine("Presence Event: " + presence.Channel + " - " + presence.Event);
            },
            (pubnubObj, status) =>
            {
                // Handle status events (optional)
                if (status.Category == PNStatusCategory.PNConnectedCategory)
                {
                    // Successfully subscribed to the channel
                    Console.WriteLine("Subscribed to Channel: " + status.AffectedChannels[0]);
                }
                else if (status.Category == PNStatusCategory.PNReconnectedCategory)
                {
                    // Reconnected after a network disconnect
                    Console.WriteLine("Reconnected to PubNub");
                }
            }
        ));

        return _message;
    }
}
