﻿using Newtonsoft.Json;
using PubNub_Demo.Models;

namespace PubNub_Demo.Service;

public class DataService
{
    private readonly PubNubService _pubnubService;
    private readonly string _jsonFilePath;

    public DataService(PubNubService pubnubService)
    {
        _pubnubService = pubnubService;
        _jsonFilePath = "Data/Chat.json";
    }

    private Data ReadData()
    {
        string jsonContent = File.ReadAllText(_jsonFilePath);
        if (string.IsNullOrEmpty(jsonContent)) return new Data();

        Data data = JsonConvert.DeserializeObject<Data>(jsonContent)!;
        return data;
    }

    private void WriteData(Data data)
    {
        string jsonContent = JsonConvert.SerializeObject(data);
        File.WriteAllText(_jsonFilePath, jsonContent);
    }

    public bool AddUser(string username, string password, string name)
    {
        Data data = ReadData();

        if (data.Users.Any(x => x.Username!.ToLower() == username.ToLower()))
            return false;

        User newUser = new User
        {
            Username = username,
            Password = password,
            Name = name,
            UserId = Guid.NewGuid()
        };

        data.Users.Add(newUser);
        WriteData(data);
        return true;
    }

    public User? CheckLogin(string username, string password)
    {
        Data data = ReadData();
        return data.Users.FirstOrDefault(x => x.Username!.ToLower() == username.ToLower() && x.Password == password);
    }

    public async Task<List<User>> GetUsersAndSubscribe(string excludeUserName, Guid excludeUserId)
    {
        Data data = ReadData();
        User? myUser = data.Users.FirstOrDefault(x => x.UserId == excludeUserId);
        IEnumerable<User> filteredUsers = data.Users.Where(x => x.Username!.ToLower() != excludeUserName);

        List<PrivateChannel> channels = new List<PrivateChannel>();
        foreach (var user in filteredUsers)
        {
            PrivateChannel channel = GetChannel(user.UserId, excludeUserId);
            channel = GetIfExistsOrAdd(channel, user.UserId, excludeUserId);
            channels.Add(channel);
        }

        var token = await _pubnubService.GrantToken(excludeUserId, channels);
        var channelsSubscribed = await _pubnubService.GetSubscribedChannels(token);
        var channelNames = channels.Select(x => x.ChannelName).Except(channelsSubscribed).ToList();
        await _pubnubService.SubscribeChannels(channelNames, token);

        return filteredUsers.ToList();
    }

    public User? GetUser(Guid userId)
    {
        Data data = ReadData();
        return data.Users.FirstOrDefault(x => x.UserId == userId);
    }

    public PrivateChannel? GetChannel(Guid user1, Guid user2)
    {
        Data data = ReadData();
        return data.PrivateChannels.FirstOrDefault(x =>
            (x.Initiator == user1 && x.Spectator == user2) ||
            (x.Initiator == user2 && x.Spectator == user1));
    }

    public List<ChatMessage>? GetMessages(Guid user1, Guid user2)
    {
        Data data = ReadData();
        return data.ChatMessages.Where(x =>
            (x.Sender == user1 && x.Receiver == user2) ||
            (x.Sender == user2 && x.Receiver == user1)).ToList();
    }

    public bool AddChannel(PrivateChannel channel)
    {
        Data data = ReadData();
        data.PrivateChannels.Add(channel);
        WriteData(data);
        return true;
    }

    public PrivateChannel GetIfExistsOrAdd(PrivateChannel? channel, Guid user1, Guid user2)
    {
        if (channel == null)
        {
            var channelName = $"private-{user1}-{user2}";
            channel = new PrivateChannel
            {
                ChannelName = channelName,
                ChannelId = Guid.NewGuid(),
                Initiator = user1,
                Spectator = user2
            };

            AddChannel(channel);
        }

        return channel;
    }

    public async Task<bool> CheckIfSubscribedOrSubscribe(PrivateChannel? channel, Guid user1, Guid user2)
    {
        string channelName = channel?.ChannelName ?? string.Empty;
        bool isSubscribed = await _pubnubService.IsChannelSubscribedAsync(channelName);
        return isSubscribed;
    }

    public async Task<bool> SendMessage(ChatMessage message)
    {
        Data data = ReadData();
        PrivateChannel? channel = GetChannel(message.Sender, message.Receiver);
        if (channel == null)
        {
            channel = GetIfExistsOrAdd(channel, message.Sender, message.Receiver);
        }

        await _pubnubService.PublishMessage(message.Message, channel.ChannelName, message.Sender);
        data.ChatMessages.Add(message);
        WriteData(data);
        return true;
    }
}