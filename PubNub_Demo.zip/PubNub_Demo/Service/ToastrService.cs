﻿using Microsoft.AspNetCore.Http;

namespace PubNub_Demo.Service;

public static class ToastrService
{
    public static void ShowSuccess(string message)
    {
        //var toastOptions = new ToastrOptions
        //{
        //    CloseButton = true,
        //    TimeOut = 3000,
        //    PositionClass = "toast-bottom-right"
        //};

        //var toastrScript = $@"<script type=""text/javascript"">
        //                        toastr.success(""{message}"");
        //                    </script>";

        //var httpContextAccessor = new HttpContextAccessor();
        //httpContextAccessor.HttpContext.Response.Headers.Append("ToastrScript", toastrScript);
    }
}
